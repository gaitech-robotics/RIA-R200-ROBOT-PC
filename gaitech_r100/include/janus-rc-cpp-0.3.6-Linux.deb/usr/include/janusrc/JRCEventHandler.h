/**
 * janusrc/JRCEventHandler.h
 * 	Copyright (c) 2021, Gaitech Robotics
 * 	Created on 08 June, 2021
 * 		Author: usama
 */

#ifndef _JRC_EVENTHANDLER_H_
#define	_JRC_EVENTHANDLER_H_

#include <janusrc/JRCDtypes.h>
#include <queue>
#include <memory>
#include <thread>
#include <mutex>
#include <condition_variable>

namespace JanusRC {
	/**
	 * 	Logging Functionality
	 */
	
	// Logging Levels //
	enum LogLevel {
		LOG_LEVEL_ERROR = 0,
		LOG_LEVEL_WARN,
		LOG_LEVEL_INFO,
		LOG_LEVEL_DEBUG,
		LOG_LEVEL_TRACE
	};
	/*
	*	Sink of Error Logs
	*/
	namespace internal {
		class _Logger {
		public:
			_Logger();
			virtual ~_Logger();
			// Logging Functions //
			virtual void log(const LogLevel& lvl, const std::string& module, const std::string& msg);
		protected:
			void _terminal_log(const LogLevel& lvl, const std::string& module, const std::string& msg);
		private:
			_Logger(const _Logger& cpy) = delete;
			const _Logger& operator=(const _Logger& rhs) = delete;
		};
	}
	typedef internal::_Logger*				Logger;
	// HMI Exceptions //
	class JANUSRC_DLL_EXPORT JanusRCExcpetion : public std::exception {
	public:
		JanusRCExcpetion(const std::string& module, const std::string& error);
		virtual ~JanusRCExcpetion();
		virtual const char* what() const throw();
		void				log_exception(Logger logger);
	protected:
		std::string			module;
		std::string			error;
	private:
	};
	// Event Types //
	enum class EventType {
		GENERIC,
		ROBOT_MOTOR_CONTROLLER_DATA,
		ROBOT_WHEEL_ODOMETRY_DATA,
	};
	// Make an Event Queue //
	struct JANUSRC_DLL_EXPORT Event {
		TimeStamp			time_stamp;
		const EventType		event_type;
		void*				data;
		const size_t		data_size;
		// Helping Functions //
		bool				operator!=(const Event& other) const;
		inline	bool		operator==(const Event& other) const { return !(*this != other); }
		bool				empty() const;
		bool				same_as(const Event& other) const;
		std::string			to_string() const;
		// Constructor / Destructor //
		Event();
		Event(const EventType event_type, void* data, const size_t data_size);
		Event(const Event& cpy);
		const Event& operator=(const Event& rhs) = delete;
		~Event();
	};
	/////// Conversion to Callback Data //
	JANUSRC_FUNCTION_EXPORT		Velocity2D			Event2Velocity2D(const Event &event);
	JANUSRC_FUNCTION_EXPORT		MotorController::MotorCallbackData	Event2MotorCallbackData(const Event& event);
	///////////////////
	typedef		std::queue<Event>			EventQueue;
	// Event Handler //
	typedef void	(*EventHandlerFunc)(const Event& trigger_event, void *user_data);
	struct JANUSRC_DLL_EXPORT EventHandler {
		EventHandlerFunc		handler;
		void*					user_data;
		EventHandler(EventHandlerFunc func=nullptr, void* usd=nullptr) : handler(func), user_data(usd) {}
	};
	typedef		std::vector<EventHandler>	ListHandler;
	// Event Dispatcher //
	class JANUSRC_DLL_EXPORT EventDispatcher {
	public:
		void					send_event(const Event &event);
		void					add_handler(const EventHandler& handler);
		void					remove_handler(const EventHandler& handler);
		void					remove_handler_all();
		void					clear();
		// Constructor / Destructors //
		EventDispatcher(const int maxe=1000);
		~EventDispatcher();
	protected:
		const int				max_events;
		EventQueue				queue;
		ListHandler				handlers;
		//	Throw HMI Exception	//
		void					start_thread();
		void					stop_thread();
	private:
		bool					do_quit, is_running;
		std::thread				thread;
		std::condition_variable	sig_wakeup   ;
		std::mutex				mtx_sig, mtx_data, mtx_handler;
		// Thread Processing //
		void					_thloop();
		static void				_thread_main(void* ptr);
		EventDispatcher(const EventDispatcher& cpy) = delete;
		const EventDispatcher& operator=(const EventDispatcher& rhs) = delete;
	};
}

#endif // _JRC_EVENTHANDLER_H_