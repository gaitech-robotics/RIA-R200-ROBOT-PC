/**
 * janusrc/JRCDtypes.h
 * 	Copyright (c) 2021, Gaitech Robotics
 * 	Created on 26 April, 2021
 * 		Author: usama
 */

#ifndef _JRC_DTYPES_H_
#define	_JRC_DTYPES_H_

#include <string>
#include <vector>
#include <mutex>
#include <condition_variable>

////////////////////////////////////////////////////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
  #define JANUSRC_DLL_IMPORT __declspec(dllimport)
  #define JANUSRC_DLL_EXPORT __declspec(dllexport)
  #define JANUSRC_DLL_LOCAL
#else
  #if __GNUC__ >= 4
    #define JANUSRC_DLL_IMPORT __attribute__ ((visibility ("default")))
    #define JANUSRC_DLL_EXPORT __attribute__ ((visibility ("default")))
    #define JANUSRC_DLL_LOCAL  __attribute__ ((visibility ("hidden")))
  #else
    #define JANUSRC_DLL_IMPORT
    #define JANUSRC_DLL_EXPORT
    #define JANUSRC_DLL_LOCAL
  #endif
#endif
#define	JANUSRC_FUNCTION_EXPORT extern "C" JANUSRC_DLL_EXPORT

namespace JanusRC {
	typedef uint32_t					TimeStamp;							// Time Stamp in Milli-Seconds
	JANUSRC_FUNCTION_EXPORT	TimeStamp	BuildTimeStamp(const uint32_t hr, const uint32_t min, const uint32_t sec, const uint32_t ms);
	JANUSRC_FUNCTION_EXPORT	std::string	TimeStamp2Str(const TimeStamp& ts);	// Time Stamp to Friendly String for printing
	/**
	 * 	Motor Controller Public API
	 */
	namespace MotorController {
		enum MotorCallbackEvent {							// Callback Function Events
			MCEvent_Assigned,								// Motor Assigned Dynamic ID
			MCEvent_MotorTimedOut,							// Motor Timed Out
			MCEvent_Beat,									// Motor Beat Signal
			MCEvent_StopSig,								// Got Stop Signal
			MCEvent_Status,									// Motor Program Status Updated
			MCEvent_Error,									// Motor Error
			MCEvent_Mode,									// Motor Control Mode Updated
			MCEvent_FWInfo,									// Motor Firmware Info Updated
			MCEvent_DefParams,								// Motor Definition Params Updated
			MCEvent_CalibParams,							// Motor Calibration Params Updated
			MCEvent_InertiaParams,							// Motor Inertia Params Updated
			MCEvent_PIDCurrent,								// Motor PID Current Params Updated
			MCEvent_PIDSpeed,								// Motor PID Speed Params Updated
			MCEvent_Bias,									// Motor Bias Updated
			MCEvent_MotorInfo,								// Motor Info has been updated
			MCEvent_GateInfo,								// Motor Gate Info Updated
			MCEvent_GateSet,								// Motor Gate Cleared/Reset
			MCEvent_BusVolts,								// Motor Bus Voltage Updated
			MCEvent_FBSpeed,								// Motor Speed Feedback Updated
			MCEvent_FBCurrent,								// Motor Current Feedback Updated
			MCEvent_FBCmdSig,								// Motor Command Feedback Updated
			MCEvent_Sample_PIDCurrent,						// Motor Recieved a sample for PID Current
			MCEvent_Sample_PIDCurrentSig,					// Motor Recieved a sample for PID Current Signal
			MCEvent_Sample_PIDSpeed,						// Motor Recieved a sample for PID Speed
			MCEvent_Sample_PIDSpeedSig,						// Motor Recieved a sample for PID Speed Signal
			MCEvent_Sample_ADRC,							// Motor Recieved a sample for ADRC Speed
			MCEvent_Sample_ADRCSig							// Motor Recieved a sample for ADRC Speed Signal
		};
		struct MotorCallbackData {
			MotorCallbackEvent		event;
			uint32_t				index;
			const void*				obj_ptr;
		};
		/**
		 * 		Motor Controller Status Enumeration
		 */
		enum MotorControllerStatus {
			MCS_None,									// None Status
			MCS_Booted,									// Motor Controller successfully booted
			MCS_WaitInit, 								// Motor Controller in wait state
			MCS_WaitEnd,     							// Motor Controller wait state finished
			MCS_DiagnosticsInit,  						// Motor Controller Diagnostic Started
			MCS_DiagnosticsEnd,							// Motor Controller Diagnostic Finished
			MCS_CalibrationInit,   						// Motor Controller Calibration Started
			MCS_CalibrationEnd,   						// Motor Controller Calibration Finished
			MCS_FastCalibrationInit,  					// Motor Controller Fast Calibration Started
			MCS_FastCalibrationEnd,  					// Motor Controller Fast Calibration Finished
			MCS_InertiaInit,  							// Motor Controller Inertia Identify Started
			MCS_InertiaEnd, 							// Motor Controller Inertia Identify Finished
			MCS_TuningWait,        						// Motor Controller Tuning (waiting for params)
			MCS_TuningInit,       						// Motor Controller Tuning Started
			MCS_TuningEnd,    							// Motor Controller Tuning Finshed
			MCS_CurrentPID,  							// Motor Controller Current Loop
			MCS_SpeedPID,      							// Motor Controller Speed PID Loop
			MCS_SpeedADRC  								// Motor Controller Active Disturbance Rejection Control
		};
		/**
		 * 		Motor Controller Error Enumeration
		 */
		enum MotorControllerError {
			MCE_None,									// No Error
			MCE_DrvFault,								// Gate Driver Fault
			MCE_UserParam,								// Motor User Parameter Error
			MCE_CalibParam,								// Motor Calibration Parameter Check Failed
			MCE_CalibFailed,							// Motor Calibration Failed
			MCE_CalibFastFailed,						// Motor Fast Calibration Failed
			MCE_CalibMissing,							// Motor Calibrtion Parameters Missing
			MCE_InertiaMissing,							// Motor Inertia Parameters Missing
			MCE_TuningFailed,							// Motor Tuning Failed
			MCE_Controller								// Motor Controller Failed
		};
		JANUSRC_FUNCTION_EXPORT	std::string	 MCParamsAdvErrorCodes2Str(const uint32_t flag);
		/**
		 * 		Motor Controller Mode Enumeration
		 */
		enum MotorControllerMode {
			MCM_Init,									// Motor Controller Initializing
			MCM_Reboot,									// Motor Controller Reboot
			MCM_Fault,									// Motor Controller Gate Driver Fault
			MCM_Error,									// Motor Controller Error
			MCM_Wait,									// Motor Controller Wait Mode
			MCM_Diagnostic,								// Motor Controller Diagnostics Mode
			MCM_CalibrateMotor,							// Motor Controller Calibrate Motor
			MCM_CalibrateRs,							// Motor Controller Fast Callibrate Motor Rs
			MCM_CalibrateBias,							// Motor Controller Fast Callibrate Bias
			MCM_CalibrateInertia,						// Motor Controller Callibrate Inertia
			MCM_TuneCurrentPID,							// Motor Controller Tune Current PID
			MCM_TuneSpeedPID,							// Motor Controller Tune Speed PID
			MCM_TuneSpeedADRC,							// Motor Controller Tune Speed Active Disturbance Rejection Controller
			MCM_RunCurrentPID,							// Motor Controller Run Current PID Loop
			MCM_RunSpeedPID,							// Motor Controller Run Speed PID Loop
			MCM_RunSpeedARDC							// Motor Controller Run Speed ARDC
		};
		JANUSRC_FUNCTION_EXPORT	std::string	MCProgramModeCodes2Str(const MotorControllerMode mode);
		/**
		 * 		Motor Controller Status and Error Messages
		 */
		struct JANUSRC_DLL_EXPORT MCStatus {
			uint32_t					motor_id;		// motor dynamic id
			TimeStamp					time_stamp;		// time stamp from motor controller
			MotorControllerStatus		status;			// motor controller status
			MCStatus() : motor_id(0), time_stamp(0), status(MCS_None) { }
			MCStatus(const MCStatus &cpy) : motor_id(cpy.motor_id), time_stamp(cpy.time_stamp), status(cpy.status) { }
			const MCStatus& operator=(const MCStatus &rhs);
			~MCStatus() { }
			std::string to_string() const;
		};
		struct JANUSRC_DLL_EXPORT MCError {
			uint32_t					motor_id;		// motor dynamic id
			TimeStamp					time_stamp;		// time stamp from motor controller
			MotorControllerError		error;			// motor controller error
			MotorControllerMode			program_mode;	// program mode
			uint32_t					adv_flag;		// motor controller advanced error code
			MCError() : motor_id(0), time_stamp(0), error(MCE_None), program_mode(MCM_Init), adv_flag(0) { }
			MCError(const MCError &cpy) : motor_id(cpy.motor_id), time_stamp(cpy.time_stamp),
						error(cpy.error), program_mode(cpy.program_mode), adv_flag(cpy.adv_flag) { }
			const MCError& operator=(const MCError &rhs);
			~MCError() { }
			std::string to_string() const;
		};
		/**
		 * 		Motor Controller Board ID
		 */
		struct JANUSRC_DLL_EXPORT MCID {
			uint32_t		board_uuid;					// Board UUID
			uint16_t		board_rid;					// Board Random ID
			uint8_t			board_did;					// Board Runtime ID
			MCID()	: board_uuid(0), board_rid(0), board_did(0) { }
			MCID(const MCID &cpy) : board_uuid(cpy.board_uuid), board_rid(cpy.board_rid), board_did(cpy.board_did) { }
			const MCID&	operator=(const MCID& rhs);
			~MCID() { }
			std::string to_string() const;
			inline bool is_device() const {
				return board_uuid != 0;
			}
			inline bool is_configured() const {
				return board_did != 0;
			}
			inline bool is_device_ready() const {
				return is_device() && is_configured() && board_rid != 0;
			}
			inline bool is_same_device(const MCID& other) const {
				return board_uuid == other.board_uuid;
			}
			inline bool is_same_device_instance(const MCID& other) const {
				return is_same_device(other) && (board_rid == other.board_rid);
			}
			inline bool is_same_device_configured(const MCID& other) const {
				return is_same_device_instance(other) && (board_did == other.board_did);
			}			
		};
		/**
		 * 		Motor Controller Firmware Information
		 */
		struct JANUSRC_DLL_EXPORT FirmwareInfo {
			uint16_t		controller_version[3];		// PID Controller Version
			uint16_t		adrc_version[3];			// ARDC Controller Version
			uint16_t		firmware_version[3];		// Microcontroller Version
			float			fs_freq;					// Full Scale Frequncy in Hz
			float			fs_current;					// Full Scale Current in A
			float			fs_voltage;					// Full Scale Voltage in V
			float			board_adc_volt;				// Board Max ADC Voltage
			float			board_adc_current;			// Board Max ADC Current
			float			board_voltage_filter_pole;	// Board Voltage Filter Pole
			float			board_compiled_busvolt;		// Board (Compiled Bus Voltage)
			float			board_real_busvolt;			// Board Real Bus Voltage
			float			board_ideal_current_bias;	// Board Ideal Current Bias
			float			board_ideal_voltage_bias;	// Board Ideal Voltage Bias
			float			freq_system;				// Microcontroller Frequency in Hz
			float			freq_pwm;					// Gate Driver PWM Frequency
			float			freq_isr;					// ISR Frequency
			float			freq_ctrl;					// Controller Frequency
			float			freq_est;					// Estimator Frequency
			float			freq_speed;					// Speed Controller Frequency
			float			freq_traj;					// Trajectory Generator Frequency
			FirmwareInfo();
			FirmwareInfo(const FirmwareInfo& cpy);
			const FirmwareInfo& operator=(const FirmwareInfo& rhs);
			~FirmwareInfo() { }
			std::string to_string() const;
		};
		/**
		 * 		Motor Parameters
		 */
		struct JANUSRC_DLL_EXPORT MotorDefinitionParams {
			uint16_t		PolePairs;					// number of pole pairs
			float			MaxCurrent;					// maximum current in amperes
			float			MaxSpeed;					// maximum speed in rpm
			float			MaxAcceleration;			// maximum acceleration in rpm/s
			////////// Read only parameters //////////////
			uint16_t		Type;						// motor type
			float			Lr;							// motor rotor inductance in ohms
			float			Rr;							// motor rotor resistance in ohms
			float			MagnetizingCurrent;			// motor magnetizing current
			MotorDefinitionParams();
			MotorDefinitionParams(const MotorDefinitionParams & cpy);
			const MotorDefinitionParams& operator=(const MotorDefinitionParams &rhs);
			~MotorDefinitionParams() { }
			std::string to_string() const;
			inline bool			valid() const {
				if (this->PolePairs == 0) return false;
				if (this->MaxCurrent <= 0.0) return false;
				if (this->MaxSpeed <= 0.0) return false;
				if (this->MaxAcceleration <= 0.0) return false;
				return true;
			}
		};
		struct JANUSRC_DLL_EXPORT MotorCalibParams {
			float			Flux;						// motor flux in V/Hz
			float			Rs;							// motor stator resistance in ohms
			float			Lsd;						// motor direct stator inductance in Henry
			float			Lsq;						// motor quadrature stator inductance in Henry
			MotorCalibParams() : Flux(0.0), Rs(0.0), Lsd(0.0), Lsq(0.0) { }
			MotorCalibParams(const MotorCalibParams& cpy) : Flux(cpy.Flux), Rs(cpy.Rs), Lsd(cpy.Lsd), Lsq(cpy.Lsq) { }
			const MotorCalibParams& operator=(const MotorCalibParams& rhs);
			~MotorCalibParams() { }
			std::string to_string() const;
			inline bool			valid() const {
				if (this->Flux <= 0.0) return false;
				if (this->Rs <= 0.0) return false;
				if (this->Lsd <= 0.0) return false;
				if (this->Lsq <= 0.0) return false;
				return true;
			}
		};
		struct JANUSRC_DLL_EXPORT MotorInertiaParams {
			float			inertia;					// inertia in internal units
			float			friction;					// friction in internal units
			float			bandwidth;					// bandwidth in internal units
			MotorInertiaParams() : inertia(0.0), friction(0.0), bandwidth(0.0) { }
			MotorInertiaParams(const MotorInertiaParams& cpy) : inertia(cpy.inertia), friction(cpy.friction), bandwidth(cpy.bandwidth) { }
			const MotorInertiaParams& operator=(const MotorInertiaParams& rhs);
			~MotorInertiaParams() { }
			std::string to_string() const;
			inline bool valid() const {
				if (this->inertia <= 0.0 ) return false;
				if (this->friction <= 0.0) return false;
				if (this->bandwidth <= 10.0) return false;
				return true;
			}
		};
		struct JANUSRC_DLL_EXPORT MotorPIDGains {
			bool			changeable;					// gains are changeable
			float			Kp;							// proportional gain
			float			Ki;							// integral gain
			MotorPIDGains() : changeable(false), Kp(0.0), Ki(0.0) { }
			MotorPIDGains(const MotorPIDGains& cpy) : changeable(cpy.changeable), Kp(cpy.Kp), Ki(cpy.Ki) { }
			const MotorPIDGains& operator=(const MotorPIDGains& rhs);
			~MotorPIDGains() { }
			std::string to_string() const;
		};
		struct JANUSRC_DLL_EXPORT BoardBias {
			float			BiasI[3];					// Current Sensor Bias in Amperes
			float			BiasV[3];					// Voltage Sensor Bias in Volts
			uint32_t		_biasI[3];					// Current Sensor Bias in fixed point float for internal representation
			uint32_t		_biasV[3];					// Voltage Sensor Bias in fixed point float for internal representation
			BoardBias();
			BoardBias(const BoardBias& cpy);
			const BoardBias& operator=(const BoardBias &rhs);
			~BoardBias() { }
			std::string to_string() const;
			void			setIfromFloat(const float a, const float b, const float c);
			void			setVfromFloat(const float a, const float b, const float c);
			inline bool valid() const {
				if (this->_biasI[0] == 0) return false;
				if (this->_biasI[1] == 0) return false;
				if (this->_biasI[2] == 0) return false;
				if (this->_biasV[0] == 0) return false;
				if (this->_biasV[1] == 0) return false;
				if (this->_biasV[2] == 0) return false;
				return true;
			}
		};
		struct JANUSRC_DLL_EXPORT MotorParams {
			MotorDefinitionParams	Motor;				// motor definition parameters
			MotorCalibParams		Params;				// motor callibration parameters
			MotorInertiaParams		InertiaParams;		// motor inertia parameters
			BoardBias				Bias;				// board sensor bias
			MotorPIDGains			CurrentLoop;
			MotorPIDGains			SpeedLoop;
			MotorParams() : Motor(), Params(), InertiaParams(), Bias(), CurrentLoop(), SpeedLoop() { }
			MotorParams(const MotorParams& cpy) : Motor(cpy.Motor), Params(cpy.Params), InertiaParams(cpy.InertiaParams), 
								Bias(cpy.Bias), CurrentLoop(cpy.CurrentLoop), SpeedLoop(cpy.SpeedLoop) { }
			const MotorParams& operator=(const MotorParams& rhs);
			~MotorParams() { }
			std::string to_string() const;
			void save(const std::string &filename) const;
			bool load(const std::string &filename);
		};		
		/**
		 *		Feedback Data from Motor Controller
		 */
		struct JANUSRC_DLL_EXPORT MotorSpeed {
			uint32_t 		motor_id;					// motor dynamic id
			TimeStamp		time_stamp;					// time stamp from motor controller
			float			speed_rpm;					// motor estimated speed in rpm
			MotorSpeed() : motor_id(0), time_stamp(0), speed_rpm(0.0) { }
			MotorSpeed(const MotorSpeed& cpy) : motor_id(cpy.motor_id), time_stamp(cpy.time_stamp), speed_rpm(cpy.speed_rpm) { }
			const MotorSpeed& operator=(const MotorSpeed &rhs);
			~MotorSpeed() { }
			std::string to_string() const;
		};
		struct JANUSRC_DLL_EXPORT MotorCurrent {
			uint32_t 		motor_id;					// motor dynamic id
			TimeStamp	 	time_stamp;					// time stamp from motor controller
			float			current_amperes;			// Iq dc current in amperes
			MotorCurrent() : motor_id(0), time_stamp(0), current_amperes(0.0) { }
			MotorCurrent(const MotorCurrent& cpy) : motor_id(cpy.motor_id), time_stamp(cpy.time_stamp), current_amperes(cpy.current_amperes) { }
			const MotorCurrent& operator=(const MotorCurrent& rhs);
			~MotorCurrent() { }
			std::string to_string() const;
		};
		struct JANUSRC_DLL_EXPORT MotorBusVoltage {
			uint32_t 		motor_id;					// motor dynamic id
			TimeStamp	 	time_stamp;					// time stamp from motor controller
			float			voltage_volts;				// motor bus voltage in volts
			MotorBusVoltage() : motor_id(0), time_stamp(0), voltage_volts(0.0) { };
			MotorBusVoltage(const MotorBusVoltage& cpy) : motor_id(cpy.motor_id), time_stamp(cpy.time_stamp), voltage_volts(cpy.voltage_volts) { }
			const MotorBusVoltage& operator=(const MotorBusVoltage& rhs);
			~MotorBusVoltage() { }
			std::string to_string() const;
		};
		typedef std::vector<MotorSpeed>			MSpeedArray;
		typedef std::vector<MotorCurrent>		MCurrentArray;
		typedef std::vector<MotorBusVoltage>	MVoltageArray;
		/**
		 * 		Gate Driver Info
		 */
		struct JANUSRC_DLL_EXPORT GateDriverInfo {
			bool		fetched;
			uint16_t	status_register;
			uint16_t	status_register1;
			uint16_t	ctrl_register2;
			uint16_t	ctrl_register3;
			uint16_t	ctrl_register4;
			uint16_t	ctrl_register5;
			uint16_t	ctrl_register6;
			GateDriverInfo();
			GateDriverInfo(const GateDriverInfo& cpy);
			const GateDriverInfo& operator=(const GateDriverInfo& rhs);
			~GateDriverInfo() { }
			std::string to_string() const;
		};
		std::string MCDRVReg00Str(const uint16_t reg);
		std::string MCDRVReg01Str(const uint16_t reg);
		std::string MCDRVReg02Str(const uint16_t reg);
		std::string MCDRVReg03Str(const uint16_t reg);
		std::string MCDRVReg04Str(const uint16_t reg);
		std::string MCDRVReg05Str(const uint16_t reg);
		std::string MCDRVReg06Str(const uint16_t reg);
		/**
		 * 		Motor Controller Complete Information
		 */
		struct JANUSRC_DLL_EXPORT MotorControllerInfo {
			MCID					board;				// Board ID Information
			FirmwareInfo			firmware;			// Firmware Information
			TimeStamp				time_stamp;			// TimeStamp of last update
			MotorParams				params;				// Motor Params
			MotorControllerMode		mode;				// Program Mode
			MCStatus				last_status;		// Motor Controller Last Status
			MCError					last_error;			// Motor Controller Last Error
			////////////////// Command ///////////////////
			MotorSpeed				last_commanded_speed;
			MotorCurrent			last_commanded_current;
			////////////////// Feedback //////////////////
			MotorSpeed				last_speed;
			MotorCurrent			last_current;
			MotorBusVoltage			last_bus_voltage;
			//////////////// Gate Driver Info ////////////
			GateDriverInfo			gate_driver_info;
			/////////// Member Functions /////////////////
			MotorControllerInfo();
			MotorControllerInfo(const MotorControllerInfo &cpy);
			const MotorControllerInfo& operator=(const MotorControllerInfo &rhs);
			~MotorControllerInfo() { }
			std::string to_string() const;
			void clear();								// clear data except uuid if stored
		};
		/**
		 * 		Tuning Commands
		 */		
		struct JANUSRC_DLL_EXPORT MTuneCurrentPID {
			float				ref_current;
			float				Kp;
			float				Ki;
			MCurrentArray		command;
			MCurrentArray		feedback;
			MTuneCurrentPID() : ref_current(1.0), Kp(0.0), Ki(0.0), command(), feedback() { }
			MTuneCurrentPID(const MTuneCurrentPID& cpy) : ref_current(cpy.ref_current), Kp(cpy.Kp),
						 Ki(cpy.Ki), command(cpy.command), feedback(cpy.feedback) { }
			const MTuneCurrentPID& operator=(const MTuneCurrentPID& rhs);
			~MTuneCurrentPID() { }
			std::string to_string() const;
			inline void clear() { command.clear(); feedback.clear();}
			void save(const std::string& filename) const;
		};
		struct JANUSRC_DLL_EXPORT MTuneSpeedPID {
			float				ref_speed;
			float				Kp;
			float				Ki;
			MSpeedArray			command;
			MSpeedArray			feedback;
			MTuneSpeedPID() : ref_speed(100.0), Kp(0.0), Ki(0.0), command(), feedback() { }
			MTuneSpeedPID(const MTuneSpeedPID& cpy) : ref_speed(cpy.ref_speed), Kp(cpy.Kp),
						 Ki(cpy.Ki), command(cpy.command), feedback(cpy.feedback) { }
			const MTuneSpeedPID& operator=(const MTuneSpeedPID& rhs);
			~MTuneSpeedPID() { }
			std::string to_string() const;
			inline void clear() { command.clear(); feedback.clear();}
			void save(const std::string& filename) const;
		};
		struct JANUSRC_DLL_EXPORT MTuneADRC {
			float				ref_speed;
			float				bandwdith;
			MSpeedArray			command;
			MSpeedArray			feedback;
			MTuneADRC() : ref_speed(100.0), bandwdith(0.0), command(), feedback() { }
			MTuneADRC(const MTuneADRC& cpy) : ref_speed(cpy.ref_speed), bandwdith(cpy.bandwdith), command(cpy.command), feedback(cpy.feedback) { }
			const MTuneADRC& operator=(const MTuneADRC& rhs);
			~MTuneADRC() { }
			std::string to_string() const;
			inline void clear() { command.clear(); feedback.clear();}
			void save(const std::string& filename) const;
		};
		/**
		 * 		Motor Table
		 */
		struct JANUSRC_DLL_EXPORT MotorTable {
			std::vector<std::pair<std::string, MCID> >	table;
			MotorTable() : table() { }
			MotorTable(const MotorTable& cpy) : table(cpy.table) { }
			const MotorTable& operator=(const MotorTable& rhs) {
				table = rhs.table;
				return *this;
			}
			~MotorTable() { }
			void	add_entry(const std::string &name, const uint32_t uuid, const uint8_t did);
			void	save(const std::string& filename) const;
			bool	load(const std::string& filename);
			std::string	to_string() const;
			void remove_duplicate_uuids();
			void remove_duplicate_dids();
			protected:
			void fill_up_to(const int idx);
		};
	}
	/**
	 * 	Velocity
	 */
	struct JANUSRC_DLL_EXPORT Velocity2D {
		TimeStamp					time_stamp;									// Micro-Controller Time Stamp
		float						x;											// Forward Velocity in m/s
		float						y;											// Side Velocity in m/s
		float						omega;										// Rotational Velocity in rad/s
		float						dps() const;								// Rotational Velocity in degrees per second
		void						from_dps(const float dps);					// Set Rotational Velcoity from degrees per second
		float						rps() const;								// Rotational Velocity in revolution per second
		void						from_rps(const float rps);					// Rotational Velocity from revolution per second
		float						linear_velocity() const;					// Linear Velocity
		float						linear_velocity_heading_radians() const;	// Velocity Heading in radians (forward is 0 radians)
		float						linear_velocity_heading_degrees() const;	// Velocity Heading in degrees (forward is 0 degrees)
		float						instantaneous_center() const;
		Velocity2D();
		Velocity2D(const float vx, const float vy, const float w);
		Velocity2D(const Velocity2D &cpy);
		const Velocity2D& operator=(const Velocity2D &rhs);
		~Velocity2D() { }
		std::string	to_string() const;
		std::string to_string_dps() const;			// rotational speed in degree per seconds
		std::string	to_string_dps_heading() const;	// rotational speed in degree per seconds, linear velocity single number with heading direction
		std::string to_string_rps() const;			// rotational speed in revolution per seconds
		std::string	to_string_rps_heading() const;	// rotational speed in revolution per seconds, linear velocity single number with heading direction
	};
	/**
	 * 	Differential Configuration
	 */
	struct JANUSRC_DLL_EXPORT DifferentialRobotConfiguration {
		const size_t						idxLeft;				// index of left motor
		const size_t						idxRight;				// index of right motor
		float								axle_length;			// axle length between two wheels
		float								wheel_radii;			// wheel radius
		float								transmission_ratio;		// motor transmission ratio
		float								motor_min;				// motor minimum rpm
		float								motor_max;				// motor maximum rpm
		TimeStamp							motor_feedback_sync_ms;	// motor feedback time syncing in milli-seconds
		bool								use_odometry;			// use odometry
		bool								use_adrc;				// use ADRC instead of PID
		std::string							table_filename;			// Table filename
		MotorController::MotorParams		motor_params[2];
		MotorController::MotorTable			motor_table;
		DifferentialRobotConfiguration();
		DifferentialRobotConfiguration(const DifferentialRobotConfiguration& cpy);
		const DifferentialRobotConfiguration& operator=(const DifferentialRobotConfiguration &rhs);
		~DifferentialRobotConfiguration();
		std::string							to_string() const;
		// Robot Configuration Save Load //
		void	save(const std::string &filename) const;
		bool	load(const std::string &filename, const bool only_config=false);
		// Helping Functions //
		float	get_minimium_forward_velocity() const;
		float	get_maximum_forward_velocity() const;
		float	get_minimum_inplace_omega() const;
		float	get_maximum_inplace_omega() const;
		bool	valid() const;
		bool	ClipRPM(const float &left_in, const float &right_in,
							float* left_out, float *right_out) const;
		bool	ClipVelocity(Velocity2D *in_out) const;
		Velocity2D	RPMtoVelocity(const float &left_in, const float &right_in) const;
		void	Velocity2RPM(const Velocity2D &velin, float *left_out, float *right_out) const;
	};
	typedef std::vector<std::string>		ListString;
}

#endif // _JRC_DTYPES_H_