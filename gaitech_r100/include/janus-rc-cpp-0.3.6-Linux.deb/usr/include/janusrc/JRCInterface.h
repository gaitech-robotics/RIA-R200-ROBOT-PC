/**
 * janusrc/JRCInterface.h
 * 	Copyright (c) 2021, Gaitech Robotics
 * 	Created on 06 May, 2021
 * 		Author: usama
 */

#ifndef _JRC_INTERFACE_H_
#define	_JRC_INTERFACE_H_

#include <janusrc/JRCEventHandler.h>

#define JRC_INTERFACE_DEFAULT_SERIAL_PORT					"/dev/ttyACM0"

namespace JanusRC {
	namespace internal {
		class RobotModule;			// Forward Declaration of Robot Module Class
		class DiffDriveModule;		// Forward Declaration of DiffDrive Module Class
		class DiffDriveExternalController;	// Forward Declaration of DiffDrive External Module Class
	}
	namespace MotorController {
		/**
		 * 	Motor Controller Interface
		 */
		class JANUSRC_DLL_EXPORT MotorControl {
			public:
				MotorControl(Logger logger = nullptr);
				~MotorControl();
				void			add_handler(const EventHandler& handler);
				void			remove_handler(const EventHandler& handler);
				//////////////////////////////////////////////////////////////////////////////////
				bool			load_uuid_bindings_from_file(const std::string &bfile);			// Load Binding information from a file
				void			save_uuid_bindings_to_file(const std::string &bfile) const;		// Save Binding information to a file
				void			save_motor_params_to_file(const int idx, const std::string& mfile) const;// Save paramaeters to a file
				bool			load_motor_params_from_file(const int idx, const std::string &mfile);// Load parameters to a file
				bool			load_motor_params_from_binding_file(const std::string &bfile);	// binding file to load parameters from
				//////////////////////////////////////////////////////////////////////////////////
				int				index_DID(const uint8_t did) const;								// Find motor index Corresponding to Dynmaic Identifier
				int				index_UUID(const uint32_t uuid) const;							// Find motor index Corresponding to Device UUID
				int				index_MCID(const MCID& mcid) const;								// Find motor index Corresponding to MCID structure
				int				bind_MCID(MCID &mcid);											// Bind MCID with Dynamic Identifier
				// Start Communication //
				bool 			start(const std::string &port=JRC_INTERFACE_DEFAULT_SERIAL_PORT);
				void			stop();
				int				count() const;													// Get total motor counts
				const MotorControllerInfo&	motor(const int index) const;						//  Get Motor Info at index
				// Update information of motor //
				void			update_info(const int idx);										// Update complete information of connected motor
				void			update_motor_params(const int idx);								// Update motor parameters of connected motor
				void			update_motor_firmware_info(const int idx);						// Update firmware information of connected motor
				void			update_motor_mode_info(const int idx);							// Update motor mode information
				void			update_motor_definition_params(const int idx);					// Update motor definition parameters
				void			update_motor_calib_params(const int idx);						// Update motor calibration parameters
				void			update_motor_inertia_params(const int idx);						// Update motor intertia parameters
				void			update_motor_sensor_bias(const int idx);						// Update motor sensor bias
				void			update_motor_pid_params(const int idx);							// Update motor PID parameters
				void			update_motor_time(const int idx);								// Update motor time
				void			update_motor_last_error(const int idx);							// Update motor last error
				void			update_motor_last_status(const int idx);						// Update motor last status
				void			update_gate_driver_info(const int idx);							// Changes mode to diagnostics
				// Set Functions //
				void			set_gatedriver_reset(const int idx);							// Reset Gate Driver connected to motor controller
				void			set_gatedriver_clear(const int idx);							// Clear Fault on Gate Driver connected to motor controller
				void			set_motor_sensor_bias(const int idx, BoardBias &newparams);		// Set motor sensor bias
				void			set_motor_adrc_bandwidth(const int idx, const float &bw);		// Set motor ADRC bandwidth
				void			set_motor_pid_params_current(const int idx, MotorPIDGains &newgains);// Set motor Current PID Parameters
				void			set_motor_pid_params_speed(const int idx, MotorPIDGains &newgains);	// Set motor Speed PID Parameters
				void			set_motor_params(const int idx, MotorParams &newparams);		// Set Motor Parameters
				void			set_command_current(const int idx, const float A);				// Set Command Current
				void			set_command_speed(const int idx, const float rpm);				// Set Command Speed
				/////////////// Special Functions ///////////////
				bool			calibrate_motor(const int idx, MotorDefinitionParams &newparam);// Calibrate Motor (takes about 3-5 minutes)
				bool			calibrate_rs(const int idx);									// Fast Calibrate Motor Phase Resistance
				bool			calibrate_bias(const int idx);									// Fast Calibrate Motor Controller Sensor Bias (5-10 seconds)
				bool			calibrate_inertia(const int idx);								// Calibrate Motor inertia paarameters (motor must be calibrated first)
				bool			set_mode_tune_current_pid(const int idx);						// Set Motor Controller to Current PID Tuning Mode
				bool			start_tuning_current_pid(const int idx, MotorPIDGains &newgains, const float setpoint_A);	// Start Test Run for Current PID Tuning
				bool			set_mode_tune_speed_pid(const int idx);							// Set Motor Controller to Speed PID Tuning Mode
				bool			start_tuning_speed_pid(const int idx, MotorPIDGains &newgains, const float setpoint_rpm); // Start Test Run for Speed PID Tuning
				bool			set_mode_tune_speed_adrc(const int idx);						// Set Motor Controller to Speed ADRC Tuning Mode
				bool			start_tuning_speed_adrc(const int idx, const float &bw, const float setpoint_rpm);	// Start Test Run for Speed ADRC Tuning
				MTuneCurrentPID	get_tuning_result_current_pid(const int idx);					// Get Result for Current PID Tuning
				MTuneSpeedPID	get_tuning_result_speed_pid(const int idx);						// Get Result for Speed PID Tuning
				MTuneADRC		get_tuning_result_adrc(const int idx);							// Get Result for Speed ADRC Tuning
				bool			run_motor_current(const int idx);								// Run Motor in Current PID Mode
				bool			run_motor_speed(const int idx);									// Run Motor in Speed PID Mode
				bool			run_motor_adrc(const int idx);									// Run Motor in Speed ADRC Mode
				/////// Reboot Motor and Emergency Stop /////////
				void			reboot_motor(const int idx);									// Reboot Motor
				void			emergency_stop();												// Send Emergency Stop Signal
			private:
				internal::RobotModule* 		rmodule;											// Robot Module to Handle Communication with Motor Controller
				MotorControl(const MotorControl& cpy) = delete;
				const MotorControl& operator=(const MotorControl& rhs) = delete;
		};
	}
	JANUSRC_FUNCTION_EXPORT	ListString SystemSerialPorts();
	/**
	 * 	Robot Controller Interface (R100)
	 */
	class JANUSRC_DLL_EXPORT RobotR100 {
		public:
			RobotR100(Logger logger = nullptr, const bool external_interface=false);
			~RobotR100();
			void			add_handler(const EventHandler& handler);
			void			remove_handler(const EventHandler& handler);
			// Member Functions //
			bool			load_configuration(const std::string &config_file);
			DifferentialRobotConfiguration get_configuration() const;
			void			drive_velocity(const Velocity2D& new_vel);
			void			drive_motors(const float &motor_left, const float &motor_right);
			bool			start_driving(const std::string &port=JRC_INTERFACE_DEFAULT_SERIAL_PORT);
			bool			start_driving_external(const std::string &pl, const std::string &pr, const bool dirl, const bool dirr, const bool must_use_both);
			///////// Reboot ////////////
			void			reboot_robot();													// Reboot robot
			void			emergency_stop();												// Send Emergency Stop Signal
		protected:

		private:
			internal::DiffDriveModule*				rdiffmodule;
			internal::DiffDriveExternalController* 	rdiffext;
			RobotR100(const RobotR100& cpy) = delete;
			const RobotR100& operator=(const RobotR100& rhs) = delete;
	};
}

#endif // _JRC_INTERFACE_H_